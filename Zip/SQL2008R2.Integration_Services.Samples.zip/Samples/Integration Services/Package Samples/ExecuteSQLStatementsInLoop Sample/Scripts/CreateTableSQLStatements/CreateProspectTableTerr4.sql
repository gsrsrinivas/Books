/****************************************************************************
  This file is part of the Microsoft SQL Server Code Samples.
  Copyright (C) Microsoft Corporation.  All rights reserved.

  This source code is intended only as a supplement to Microsoft
  Development Tools and/or on-line documentation.  See these other
  materials for detailed information regarding Microsoft code samples.

  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
*****************************************************************************/

/* Creates the Territory table*/
IF NOT EXISTS (SELECT * FROM AdventureWorks.sys.tables WHERE type ='U' and name = 'Territory4')
	
CREATE TABLE AdventureWorks.dbo.Territory4 (
[CustomerKey] [int] IDENTITY (1, 1) NOT NULL ,
FirstName nvarchar (15),
MiddleInitial nchar (1),
LastName nvarchar (20),
BirthDate datetime,
MaritalStatus nchar (5),
Gender nchar (1),
Salutation nvarchar (10),
EmailAddress nvarchar  (100),
YearlyIncome int,
TotalChildren tinyint,
NumberOfChildrenAtHome tinyint,
Education nvarchar(40),
Occupation nvarchar(30),
HomeOwner nchar (3),
NumberCars tinyint,
AddressLine1 nvarchar (50),
City nvarchar (30),
State nchar (3),
PostalCode nvarchar (10),
Phone nvarchar (20),
Territory int

)
ELSE TRUNCATE TABLE AdventureWorks.dbo.Territory4
