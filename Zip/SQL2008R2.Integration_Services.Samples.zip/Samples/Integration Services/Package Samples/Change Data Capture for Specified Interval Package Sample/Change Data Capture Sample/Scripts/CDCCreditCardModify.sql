/*=====================================================================
  This file is part of a Microsoft SQL Server Shared Source Application.
  Copyright (C) Microsoft Corporation.  All rights reserved.
 
THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.
======================================================= */
declare @Iteration int, @Cnt int, @Limit int, @Val float, @CreditCardID int, @cardtype nvarchar(50),
	 @CardNumber nvarchar(25), @ExpMonth tinyint, @ExpYear smallint

set @Iteration = 0
set @Val = Rand(100)

While (@Iteration < 10)
begin
	set @Iteration = @Iteration + 1

	select @Cnt = 0, @Limit = 100

	while (@Cnt < @Limit)
	begin
		set @Cnt = @Cnt + 1

		set @Val = Rand()

		select @CreditCardID = @Val * 8000

		if exists 
		(
			select CreditCardID from CDCSample.CreditCard
			where CreditCardID = @CreditCardID
 		)
		begin
			select @cardtype = CardType
			from CDCSample.CreditCard
			where CreditCardID = @CreditCardID
		
			if @cardtype = N'SuperiorCard'
				set @cardtype = N'Vista'
			else if @cardtype = N'Vista'
				set @cardtype = N'Distinguish'
			else if @cardtype = N'Distinguish'
				set @cardtype = N'ColonialVoice'
			else
				set @cardtype = N'SuperiorCard'

			update CDCSample.CreditCard
			set CardType = @cardtype, ModifiedDate = getdate()
			where CreditCardID = @CreditCardID
 		end
	end

	waitfor delay '00:00:10'
end
go
