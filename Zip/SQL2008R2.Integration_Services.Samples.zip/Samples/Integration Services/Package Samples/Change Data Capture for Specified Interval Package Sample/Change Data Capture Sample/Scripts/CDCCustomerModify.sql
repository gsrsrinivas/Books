/*=====================================================================
  This file is part of a Microsoft SQL Server Shared Source Application.
  Copyright (C) Microsoft Corporation.  All rights reserved.
 
THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.
======================================================= */
declare @Iteration int, @Cnt int, @Limit int, @CustomerID int, @PersonID int, @StoreID int, @TerritoryID int, @Val float

set @Iteration = 0
set @Val = Rand(100)

While (@Iteration < 10)
begin
	set @Iteration = @Iteration + 1

	select @Cnt = 0, @Limit = 100

	while (@Cnt < @Limit)
	begin
		set @Cnt = @Cnt + 1

		set @Val = Rand()

		select @CustomerID = @Val * 8000

		if exists 
		(
			select CustomerID from CDCSample.Customer
			where CustomerID = @CustomerID
		)
		begin
			select @PersonID = PersonID, @StoreID = StoreID, @TerritoryID = TerritoryID
			from CDCSample.Customer
			where CustomerID = @CustomerID

			IF @StoreID IS NULL
				set @StoreID = 999
			else
				set @StoreID = @StoreID + 10
	
			IF @PersonID IS NULL
				set @PersonID = 9999
			else
				set @PersonID = @PersonID + 10
	
			set @TerritoryID = @TerritoryID + 1
			if @TerritoryID = 11
				set @TerritoryID = 1

			update CDCSample.Customer
			set PersonID = @PersonID, StoreID = @StoreID, TerritoryID = @TerritoryID, ModifiedDate = getdate()
			where CustomerID = @CustomerID
		end
	end

	waitfor delay '00:00:10'
end
go
