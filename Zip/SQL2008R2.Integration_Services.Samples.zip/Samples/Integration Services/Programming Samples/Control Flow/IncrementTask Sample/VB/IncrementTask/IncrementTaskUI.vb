'=====================================================================  	
'
'  File:       IncrementTaskUI.vb
'
'  Summary:    This file contains a Control flow task user interface.
'
'  Date:       06/09/2005
'
'---------------------------------------------------------------------
'  This file is part of the Microsoft SQL Server Code Samples.
'  Copyright (C) Microsoft Corporation.  All rights reserved.
'
'  This source code is intended only as a supplement to Microsoft
'  Development Tools and/or on-line documentation.  See these other
'  materials for detailed information regarding Microsoft code samples.
'
'  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
'  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
'  THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
'  PARTICULAR PURPOSE.
'=====================================================================                         

Imports System
Imports System.Windows.Forms
Imports Microsoft.SqlServer.Dts.Runtime
Imports Microsoft.SqlServer.Dts.Runtime.Design

Public NotInheritable Class IncrementTaskUI
    Implements IDtsTaskUI
    Private taskHostValue As TaskHost

    Public Sub New()
    End Sub

#Region "IDtsTaskUI Members"

    Function GetView() As System.Windows.Forms.ContainerControl Implements IDtsTaskUI.GetView
        Return New IncrementTaskForm(Me.taskHostValue)
    End Function

    Sub Initialize(ByVal taskHost As TaskHost, ByVal serviceProvider As IServiceProvider) Implements IDtsTaskUI.Initialize
        ' Store the TaskHost of the task.
        Me.taskHostValue = taskHost
    End Sub

    Sub Delete(ByVal parentWindow As IWin32Window) Implements IDtsTaskUI.Delete
    End Sub

    Sub [New](ByVal parentWindow As IWin32Window) Implements IDtsTaskUI.New
    End Sub
#End Region
End Class