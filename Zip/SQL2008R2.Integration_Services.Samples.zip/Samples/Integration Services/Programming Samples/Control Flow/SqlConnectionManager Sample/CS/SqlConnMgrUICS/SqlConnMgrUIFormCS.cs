using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.SqlServer.Dts.Design;
using Microsoft.SqlServer.Dts.Runtime;
using Microsoft.SqlServer.Dts.Runtime.Wrapper;
using Microsoft.SqlServer.Dts.Runtime.Design;
using System.Data.SqlClient;

namespace SqlConnMgrUICS
{
  public partial class SqlConnMgrUIFormCS : Form
  {
    private const string CONNECTIONNAME_BASE = "SqlConnectionManagerCS";

    private ConnectionManager _connectionManager;
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
    private IServiceProvider _serviceProvider;
    private string _connectionName;
    private string _serverName;
    private string _databaseName;

    public SqlConnMgrUIFormCS()
    {
      InitializeComponent();
    }

    #region " Properties "

    public string ConnectionName
    {
      get
      {
        return this._connectionName;
      }
    }

    #endregion

    public void Initialize(ConnectionManager connectionManager, IServiceProvider serviceProvider)
    {
      this._connectionManager = connectionManager;
      this._serviceProvider = serviceProvider;
      ConfigureControlsFromConnectionManager();
    }

    #region " Button events "

    private void btnOK_Click(System.Object sender, System.EventArgs e)
    {
      ConfigureConnectionManagerFromControls();
      this.DialogResult = DialogResult.OK;
    }

    private void btnCancel_Click(System.Object sender, System.EventArgs e)
    {
      this.DialogResult = DialogResult.Cancel;
    }

    #endregion

    #region " Helper functions "

    private void ConfigureControlsFromConnectionManager()
    {
      string tempServerName;
      string tempDatabaseName;

      {
        tempServerName = _connectionManager.Properties["ServerName"].GetValue(_connectionManager).ToString();
        if (!String.IsNullOrEmpty(tempServerName))
        {
          _serverName = tempServerName;
          txtServerName.Text = _serverName;
        }

        tempDatabaseName = _connectionManager.Properties["DatabaseName"].GetValue(_connectionManager).ToString();
        if (!String.IsNullOrEmpty(tempDatabaseName))
        {
          _databaseName = tempDatabaseName;
          txtDatabaseName.Text = _databaseName;
        }
      }
    }

    private void ConfigureConnectionManagerFromControls()
    {
      string tempServerName;
      string tempDatabaseName;

      tempServerName = txtServerName.Text;
      tempDatabaseName = txtDatabaseName.Text;

      _connectionName = CONNECTIONNAME_BASE + "." + tempServerName + "." + tempDatabaseName;

      {
        _connectionManager.Properties["Name"].SetValue(_connectionManager, _connectionName);
        _connectionManager.Properties["ServerName"].SetValue(_connectionManager, tempServerName);
        _connectionManager.Properties["DatabaseName"].SetValue(_connectionManager, tempDatabaseName);
      }
    }

    #endregion
  }
}