using System;
using Microsoft.SqlServer.Dts.Design;
using Microsoft.SqlServer.Dts.Runtime;
using Microsoft.SqlServer.Dts.Runtime.Wrapper;
using Microsoft.SqlServer.Dts.Runtime.Design;
using System.Windows.Forms;

namespace Excel2ConnMgrUICS
{
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1724:TypeNamesShouldNotMatchNamespaces"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")]
    public class Excel2ConnMgrUICS :
      IDtsConnectionManagerUI
    {
        #region  Variables

        private ConnectionManager _connectionManager;
        private IServiceProvider _serviceProvider;

        #endregion

        #region  IDtsConnectionManagerUI interface

        public void Delete(System.Windows.Forms.IWin32Window parentWindow)
        {
            // Not implemented
        }

        public bool Edit(System.Windows.Forms.IWin32Window parentWindow, Microsoft.SqlServer.Dts.Runtime.Connections connections, Microsoft.SqlServer.Dts.Runtime.Design.ConnectionManagerUIArgs connectionUIArg)
        {
            return EditExcel2Connection(parentWindow);
        }

        public void Initialize(Microsoft.SqlServer.Dts.Runtime.ConnectionManager connectionManager, System.IServiceProvider serviceProvider)
        {
            this._connectionManager = connectionManager;
            this._serviceProvider = serviceProvider;
        }

        public bool New(System.Windows.Forms.IWin32Window parentWindow, Microsoft.SqlServer.Dts.Runtime.Connections connections, Microsoft.SqlServer.Dts.Runtime.Design.ConnectionManagerUIArgs connectionUIArg)
        {
            // If connection manager has been copied and pasted, take no action.
            IDtsClipboardService clipboardService;
            clipboardService = (IDtsClipboardService)this._serviceProvider.GetService(typeof(IDtsClipboardService));
            if (clipboardService != null)
            {
                if (clipboardService.IsPasteActive)
                {
                    return true;
                }
            }

            return EditExcel2Connection(parentWindow);
        }

        #endregion

        #region  Helper functions

        private bool EditExcel2Connection(IWin32Window parentWindow)
        {
            Excel2ConnMgrUIFormCS excel2CMUIForm = new Excel2ConnMgrUIFormCS();
            excel2CMUIForm.Initialize(_connectionManager, this._serviceProvider);
            if (excel2CMUIForm.ShowDialog(parentWindow) == DialogResult.OK)
            {
                excel2CMUIForm.Dispose();
                return true;
            }
            else
            {
                excel2CMUIForm.Dispose();
                return false;
            }
        }

        #endregion
    }
}
