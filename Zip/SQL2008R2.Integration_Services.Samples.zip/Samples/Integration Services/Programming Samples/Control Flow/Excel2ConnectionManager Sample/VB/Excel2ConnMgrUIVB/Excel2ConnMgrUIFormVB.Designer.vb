<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Excel2ConnMgrUIFormVB
  Inherits System.Windows.Forms.Form

  'Form overrides dispose to clean up the component list.
  <System.Diagnostics.DebuggerNonUserCode()> _
  Protected Overrides Sub Dispose(ByVal disposing As Boolean)
    If disposing AndAlso components IsNot Nothing Then
      components.Dispose()
    End If
    MyBase.Dispose(disposing)
  End Sub

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.IContainer

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> _
  Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Excel2ConnMgrUIFormVB))
        Me.Label1 = New System.Windows.Forms.Label
        Me.lblExcelFile = New System.Windows.Forms.Label
        Me.btnBrowse = New System.Windows.Forms.Button
        Me.chkHDR = New System.Windows.Forms.CheckBox
        Me.chkIMEX = New System.Windows.Forms.CheckBox
        Me.btnOK = New System.Windows.Forms.Button
        Me.btnCancel = New System.Windows.Forms.Button
        Me.ofdBrowse = New System.Windows.Forms.OpenFileDialog
        Me.SuspendLayout()
        '
        'Label1
        '
        resources.ApplyResources(Me.Label1, "Label1")
        Me.Label1.Name = "Label1"
        '
        'lblExcelFile
        '
        Me.lblExcelFile.BackColor = System.Drawing.SystemColors.Window
        Me.lblExcelFile.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        resources.ApplyResources(Me.lblExcelFile, "lblExcelFile")
        Me.lblExcelFile.Name = "lblExcelFile"
        '
        'btnBrowse
        '
        resources.ApplyResources(Me.btnBrowse, "btnBrowse")
        Me.btnBrowse.Name = "btnBrowse"
        Me.btnBrowse.UseVisualStyleBackColor = True
        '
        'chkHDR
        '
        resources.ApplyResources(Me.chkHDR, "chkHDR")
        Me.chkHDR.Checked = True
        Me.chkHDR.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkHDR.Name = "chkHDR"
        Me.chkHDR.UseVisualStyleBackColor = True
        '
        'chkIMEX
        '
        resources.ApplyResources(Me.chkIMEX, "chkIMEX")
        Me.chkIMEX.Name = "chkIMEX"
        Me.chkIMEX.UseVisualStyleBackColor = True
        '
        'btnOK
        '
        resources.ApplyResources(Me.btnOK, "btnOK")
        Me.btnOK.Name = "btnOK"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        resources.ApplyResources(Me.btnCancel, "btnCancel")
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'Excel2ConnMgrUIFormVB
        '
        resources.ApplyResources(Me, "$this")
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnOK)
        Me.Controls.Add(Me.chkIMEX)
        Me.Controls.Add(Me.chkHDR)
        Me.Controls.Add(Me.btnBrowse)
        Me.Controls.Add(Me.lblExcelFile)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Excel2ConnMgrUIFormVB"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
  Friend WithEvents Label1 As System.Windows.Forms.Label
  Friend WithEvents lblExcelFile As System.Windows.Forms.Label
  Friend WithEvents btnBrowse As System.Windows.Forms.Button
  Friend WithEvents chkHDR As System.Windows.Forms.CheckBox
  Friend WithEvents chkIMEX As System.Windows.Forms.CheckBox
  Friend WithEvents btnOK As System.Windows.Forms.Button
  Friend WithEvents btnCancel As System.Windows.Forms.Button
  Friend WithEvents ofdBrowse As System.Windows.Forms.OpenFileDialog
End Class
