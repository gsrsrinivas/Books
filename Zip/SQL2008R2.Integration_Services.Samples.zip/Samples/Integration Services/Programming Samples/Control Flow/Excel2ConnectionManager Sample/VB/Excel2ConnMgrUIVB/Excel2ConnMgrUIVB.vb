Imports Microsoft.SqlServer.Dts.Design
Imports Microsoft.SqlServer.Dts.Runtime
Imports Microsoft.SqlServer.Dts.Runtime.Wrapper
Imports Microsoft.SqlServer.Dts.Runtime.Design
Imports System.Windows.Forms

<System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1724:TypeNamesShouldNotMatchNamespaces")> _
<System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1705:LongAcronymsShouldBePascalCased")> _
Public Class Excel2ConnMgrUIVB
    Implements IDtsConnectionManagerUI

#Region " Variables "

    Private _connectionManager As ConnectionManager
    Private _serviceProvider As IServiceProvider

#End Region

#Region " IDtsConnectionManagerUI interface "

    Public Sub Delete(ByVal parentWindow As System.Windows.Forms.IWin32Window) Implements Microsoft.SqlServer.Dts.Runtime.Design.IDtsConnectionManagerUI.Delete
        ' Not implemented
    End Sub

    Public Function Edit(ByVal parentWindow As System.Windows.Forms.IWin32Window, ByVal connections As Microsoft.SqlServer.Dts.Runtime.Connections, ByVal connectionUIArg As Microsoft.SqlServer.Dts.Runtime.Design.ConnectionManagerUIArgs) As Boolean Implements Microsoft.SqlServer.Dts.Runtime.Design.IDtsConnectionManagerUI.Edit
        Return EditExcel2Connection(parentWindow)
    End Function

    Public Sub Initialize(ByVal connectionManager As Microsoft.SqlServer.Dts.Runtime.ConnectionManager, ByVal serviceProvider As System.IServiceProvider) Implements Microsoft.SqlServer.Dts.Runtime.Design.IDtsConnectionManagerUI.Initialize
        Me._connectionManager = connectionManager
        Me._serviceProvider = serviceProvider
    End Sub

    Public Function [New](ByVal parentWindow As System.Windows.Forms.IWin32Window, ByVal connections As Microsoft.SqlServer.Dts.Runtime.Connections, ByVal connectionUIArg As Microsoft.SqlServer.Dts.Runtime.Design.ConnectionManagerUIArgs) As Boolean Implements Microsoft.SqlServer.Dts.Runtime.Design.IDtsConnectionManagerUI.New
        Dim clipboardService As IDtsClipboardService
        clipboardService = DirectCast(Me._serviceProvider.GetService(GetType(IDtsClipboardService)), IDtsClipboardService)
        If Not clipboardService Is Nothing Then
            ' If connection manager has been copied and pasted, take no action.
            If clipboardService.IsPasteActive Then
                Return True
            End If
        End If

        Return EditExcel2Connection(parentWindow)
    End Function

#End Region

#Region " Helper functions "

    Private Function EditExcel2Connection(ByVal parentWindow As IWin32Window) As Boolean
        Dim excel2CMUIForm As New Excel2ConnMgrUIFormVB
        excel2CMUIForm.Initialize(Me._connectionManager, Me._serviceProvider)
        If excel2CMUIForm.ShowDialog(parentWindow) = DialogResult.OK Then
            excel2CMUIForm.Dispose()
            Return True
        Else
            excel2CMUIForm.Dispose()
            Return False
        End If
    End Function

#End Region

End Class
