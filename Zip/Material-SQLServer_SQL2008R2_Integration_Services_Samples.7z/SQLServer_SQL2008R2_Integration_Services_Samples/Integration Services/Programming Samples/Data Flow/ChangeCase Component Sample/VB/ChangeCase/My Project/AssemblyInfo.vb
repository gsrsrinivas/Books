Imports System
Imports System.Security.Permissions
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("ChangeCase")> 
<Assembly: AssemblyDescription("")> 
<Assembly: AssemblyCompany("Microsoft Corporation")> 
<Assembly: AssemblyProduct("ChangeCaseVB")> 
<Assembly: AssemblyCopyright("Copyright � Microsoft Corporation 2005")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)> 
<Assembly: Guid("7bc08a53-d8ab-4a22-ac2a-27237a59bf1d")> 
<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 
<Assembly: PermissionSet(SecurityAction.RequestMinimum)> 
<Assembly: CLSCompliant(True)> 
