//=====================================================================  	
//
//  File:       IncrementTaskUI.cs
//
//  Summary:    This file contains a Control flow task user interface.
//
//  Date:       06/09/2005
//
//---------------------------------------------------------------------
//  This file is part of the Microsoft SQL Server Code Samples.
//  Copyright (C) Microsoft Corporation.  All rights reserved.
//
//  This source code is intended only as a supplement to Microsoft
//  Development Tools and/or on-line documentation.  See these other
//  materials for detailed information regarding Microsoft code samples.
//
//  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
//  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
//  THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
//  PARTICULAR PURPOSE.
//=====================================================================                         

using System;
using System.Windows.Forms;
using Microsoft.SqlServer.Dts.Runtime;
using Microsoft.SqlServer.Dts.Runtime.Design;

namespace Microsoft.Samples.SqlServer.Dts
{
    public sealed class IncrementTaskUI : IDtsTaskUI
    {
        private TaskHost taskHostValue;

        public IncrementTaskUI()
        {
        }

        #region IDtsTaskUI Members

        System.Windows.Forms.ContainerControl IDtsTaskUI.GetView()
        {
            return new IncrementTaskForm(this.taskHostValue);
        }

        void IDtsTaskUI.Initialize(TaskHost taskHost, IServiceProvider serviceProvider)
        {
            // Store the TaskHost of the task.
            this.taskHostValue = taskHost;
        }

        void IDtsTaskUI.Delete(IWin32Window parentWindow)
        {
        }

        void IDtsTaskUI.New(IWin32Window parentWindow)
        {
        }
        #endregion
    }
}
