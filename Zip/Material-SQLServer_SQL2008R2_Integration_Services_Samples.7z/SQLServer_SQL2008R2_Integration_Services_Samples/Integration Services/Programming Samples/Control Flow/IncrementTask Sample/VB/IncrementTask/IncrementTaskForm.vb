'=====================================================================  	
'
'  File:       IncrementTaskForm.vb
'
'  Summary:    This file contains a Control flow task form.
'
'  Date:       06/09/2005
'
'---------------------------------------------------------------------
'  This file is part of the Microsoft SQL Server Code Samples.
'  Copyright (C) Microsoft Corporation.  All rights reserved.
'
'  This source code is intended only as a supplement to Microsoft
'  Development Tools and/or on-line documentation.  See these other
'  materials for detailed information regarding Microsoft code samples.
'
'  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
'  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
'  THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
'  PARTICULAR PURPOSE.
'=====================================================================                         

Imports System
Imports System.Globalization
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports Microsoft.SqlServer.Dts.Runtime

Partial Public Class IncrementTaskForm 'The Partial modifier is only required on one class definition per project.
    Inherits Form
    Private taskHostValue As TaskHost

    Public Sub New(ByVal taskHost As TaskHost)
        InitializeComponent()

        Me.taskHostValue = taskHost

        ' Initialize TextBox controls with the values from the Task. These properties are accessed
        ' through the task's TaskHost object.
        Me.txtInitialValue.Text = Me.taskHostValue.Properties("InitialValue").GetValue(taskHost).ToString()
        Me.txtLoopCount.Text = Me.taskHostValue.Properties("LoopCount").GetValue(taskHost).ToString()
        Me.txtIncrementValue.Text = Me.taskHostValue.Properties("IncrementValue").GetValue(Me.taskHostValue).ToString()
    End Sub

    Private Sub cmdOk_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdOk.Click
        ' Set the properties of the task through the its TaskHost object.
        Me.taskHostValue.Properties("LoopCount").SetValue(Me.taskHostValue, System.Convert.ToInt32(Me.txtLoopCount.Text, System.Globalization.CultureInfo.InvariantCulture))
        Me.taskHostValue.Properties("InitialValue").SetValue(Me.taskHostValue, System.Convert.ToInt32(Me.txtInitialValue.Text, System.Globalization.CultureInfo.InvariantCulture))
        Me.taskHostValue.Properties("IncrementValue").SetValue(Me.taskHostValue, System.Convert.ToInt32(Me.txtIncrementValue.Text, System.Globalization.CultureInfo.InvariantCulture))
    End Sub

    <System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId:="System.Windows.Forms.TextBoxBase.set_Text(System.String)")> _
    Private Sub txtInitialValue_Leave(ByVal sender As Object, ByVal e As EventArgs) Handles txtInitialValue.Leave
        If txtInitialValue.Text.Length = 0 Then
            txtInitialValue.Text = "0"
        End If
    End Sub

    <System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId:="System.Windows.Forms.TextBoxBase.set_Text(System.String)")> _
    Private Sub txtIncrementValue_Leave(ByVal sender As Object, ByVal e As EventArgs) Handles txtIncrementValue.Leave
        If txtIncrementValue.Text.Length = 0 Then
            txtIncrementValue.Text = "0"
        End If
    End Sub

    <System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1303:DoNotPassLiteralsAsLocalizedParameters", MessageId:="System.Windows.Forms.TextBoxBase.set_Text(System.String)")> _
    Private Sub txtLoopCount_Leave(ByVal sender As Object, ByVal e As EventArgs) Handles txtLoopCount.Leave
        If txtIncrementValue.Text.Length = 0 Then
            txtIncrementValue.Text = "0"
        End If
    End Sub
End Class