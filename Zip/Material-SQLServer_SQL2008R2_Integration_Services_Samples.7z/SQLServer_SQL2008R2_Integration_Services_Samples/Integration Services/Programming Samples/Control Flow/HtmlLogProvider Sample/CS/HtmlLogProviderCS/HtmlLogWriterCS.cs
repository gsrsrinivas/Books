namespace HtmlLogProviderCS
{
    using System;
    using System.IO;
    using System.Web.UI;
    using System.Web;

    class HtmlLogWriterCS
    {
        #region Variables and Constants

        // Constants.
        private const string MESSAGE_FORMAT = "html";

        // Variables.
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
        private Microsoft.SqlServer.Dts.Runtime.Connections _connections;
        private Microsoft.SqlServer.Dts.Runtime.IDTSInfoEvents _events;
        private string _subComponent;
        private HtmlTextWriter _messageHtmlWriter;

        // Status flags.
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
        private bool _fireEventsAgain;

        #endregion

        #region Initialize

        internal HtmlLogWriterCS()
        {
            // Not implemented
        }

        internal void InitializeLogWriter(Microsoft.SqlServer.Dts.Runtime.Connections connections, Microsoft.SqlServer.Dts.Runtime.IDTSInfoEvents events, string subComponent, bool fireEventsAgain)
        {
            // Cache object references for later use.
            this._connections = connections;
            this._events = events;

            this._subComponent = subComponent;
            this._fireEventsAgain = fireEventsAgain;
        }

        #endregion

        #region OpenLog and CloseLog

        internal void OpenLogHtml(StreamWriter messageStreamWriter)
        {
            this._messageHtmlWriter = new HtmlTextWriter(messageStreamWriter);

            this._messageHtmlWriter.RenderBeginTag(HtmlTextWriterTag.Html);

            // <head>
            this._messageHtmlWriter.RenderBeginTag(HtmlTextWriterTag.Head);

            // <title>
            this._messageHtmlWriter.RenderBeginTag(HtmlTextWriterTag.Title);
            this._messageHtmlWriter.Write("SSIS Package Log - " + DateTime.Now.ToString());
            this._messageHtmlWriter.RenderEndTag(); // </title>
            this._messageHtmlWriter.RenderEndTag(); // </head>

            // <body>
            this._messageHtmlWriter.RenderBeginTag(HtmlTextWriterTag.Body);

            // Create a title within the page.
            //  (There is no easy way to obtain and include the package name.)
            this._messageHtmlWriter.RenderBeginTag(HtmlTextWriterTag.H1);
            this._messageHtmlWriter.Write("SSIS Package Log - " + DateTime.Now.ToString());
            this._messageHtmlWriter.RenderEndTag(); // </h1>

            // <table>
            this._messageHtmlWriter.AddAttribute(HtmlTextWriterAttribute.Width, "100%");
            this._messageHtmlWriter.AddAttribute(HtmlTextWriterAttribute.Border, "1");
            this._messageHtmlWriter.RenderBeginTag(HtmlTextWriterTag.Table);

            // Write header row.
            this._messageHtmlWriter.RenderBeginTag(HtmlTextWriterTag.Thead);
            this._messageHtmlWriter.RenderBeginTag(HtmlTextWriterTag.Tr);

            // 1 - logEntryName
            this._messageHtmlWriter.RenderBeginTag(HtmlTextWriterTag.Th);
            this._messageHtmlWriter.Write("Log Entry Name");
            this._messageHtmlWriter.RenderEndTag(); // </th>

            // 2 - computerName
            this._messageHtmlWriter.RenderBeginTag(HtmlTextWriterTag.Th);
            this._messageHtmlWriter.Write("Computer Name");
            this._messageHtmlWriter.RenderEndTag(); // </th>

            // 3 - operatorName
            this._messageHtmlWriter.RenderBeginTag(HtmlTextWriterTag.Th);
            this._messageHtmlWriter.Write("Operator Name");
            this._messageHtmlWriter.RenderEndTag(); // </th>

            // 4 - sourceName
            this._messageHtmlWriter.RenderBeginTag(HtmlTextWriterTag.Th);
            this._messageHtmlWriter.Write("Source Name");
            this._messageHtmlWriter.RenderEndTag(); // </th>

            // 5 - sourceID
            this._messageHtmlWriter.RenderBeginTag(HtmlTextWriterTag.Th);
            this._messageHtmlWriter.Write("Source ID");
            this._messageHtmlWriter.RenderEndTag(); // </th>

            // 6 - executionID
            this._messageHtmlWriter.RenderBeginTag(HtmlTextWriterTag.Th);
            this._messageHtmlWriter.Write("Execution ID");
            this._messageHtmlWriter.RenderEndTag(); // </th>

            // 7 - messageText
            this._messageHtmlWriter.RenderBeginTag(HtmlTextWriterTag.Th);
            this._messageHtmlWriter.Write("Message Text");
            this._messageHtmlWriter.RenderEndTag(); // </th>

            // 8 - startTime
            this._messageHtmlWriter.RenderBeginTag(HtmlTextWriterTag.Th);
            this._messageHtmlWriter.Write("Start Time");
            this._messageHtmlWriter.RenderEndTag(); // </th>

            // 9 - endTime
            this._messageHtmlWriter.RenderBeginTag(HtmlTextWriterTag.Th);
            this._messageHtmlWriter.Write("End Time");
            this._messageHtmlWriter.RenderEndTag(); // </th>

            // 10 - dataCode
            // Disregard.

            // 11 - dataBytes()
            // Disregard.

            this._messageHtmlWriter.RenderEndTag(); // </tr>
            this._messageHtmlWriter.RenderEndTag(); // </thead>
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        internal void CloseLogHtml()
        {
            string subComponentInfo = this._subComponent + "-CloseLogHtml (" + MESSAGE_FORMAT + ")";

            try
            {
                {
                    this._messageHtmlWriter.RenderEndTag(); // </table>
                    this._messageHtmlWriter.RenderEndTag(); // </body>
                    this._messageHtmlWriter.RenderEndTag(); // </html>
                    this._messageHtmlWriter.Flush();

                    // Do not close!
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                this._events.FireError(0, subComponentInfo, ex.Message, String.Empty, 0);
            }
        }

        #endregion

        #region Write individual log entries

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA1801:ReviewUnusedParameters", MessageId = "dataCode"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA1801:ReviewUnusedParameters", MessageId = "dataBytes"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        internal void LogHtml(string logEntryName, string computerName, string operatorName, string sourceName, string sourceID, string executionID, string messageText, DateTime startTime, DateTime endTime, int dataCode, byte[] dataBytes)
        {
            string subComponentInfo = this._subComponent + "-LogHtml (" + MESSAGE_FORMAT + ")";

            try
            {
                    this._messageHtmlWriter.RenderBeginTag(HtmlTextWriterTag.Tr);

                    // 1 - logEntryName
                    this._messageHtmlWriter.RenderBeginTag(HtmlTextWriterTag.Td);
                    this._messageHtmlWriter.Write(logEntryName);
                    this._messageHtmlWriter.RenderEndTag(); // </td>

                    // 2 - computerName
                    this._messageHtmlWriter.RenderBeginTag(HtmlTextWriterTag.Td);
                    this._messageHtmlWriter.Write(computerName);
                    this._messageHtmlWriter.RenderEndTag(); // </td>

                    // 3 - operatorName
                    this._messageHtmlWriter.RenderBeginTag(HtmlTextWriterTag.Td);
                    this._messageHtmlWriter.Write(operatorName);
                    this._messageHtmlWriter.RenderEndTag(); // </td>

                    // 4 - sourceName
                    this._messageHtmlWriter.RenderBeginTag(HtmlTextWriterTag.Td);
                    this._messageHtmlWriter.Write(sourceName);
                    this._messageHtmlWriter.RenderEndTag(); // </td>

                    // 5 - sourceID
                    this._messageHtmlWriter.RenderBeginTag(HtmlTextWriterTag.Td);
                    this._messageHtmlWriter.Write(sourceID);
                    this._messageHtmlWriter.RenderEndTag(); // </td>

                    // 6 - executionID
                    this._messageHtmlWriter.RenderBeginTag(HtmlTextWriterTag.Td);
                    this._messageHtmlWriter.Write(executionID);
                    this._messageHtmlWriter.RenderEndTag(); // </td>

                    // 7 - messageText
                    this._messageHtmlWriter.RenderBeginTag(HtmlTextWriterTag.Td);

                    // Some event messages have no associated text.
                    if (String.IsNullOrEmpty(messageText))
                    {
                        this._messageHtmlWriter.Write("&nbsp;");
                    }
                    else
                    {
                        this._messageHtmlWriter.Write(HttpUtility.HtmlEncode(messageText));
                    }

                    this._messageHtmlWriter.RenderEndTag(); // </td>

                    // 8 - startTime
                    this._messageHtmlWriter.RenderBeginTag(HtmlTextWriterTag.Td);
                    this._messageHtmlWriter.Write(startTime.ToString());
                    this._messageHtmlWriter.RenderEndTag(); // </td>

                    // 9 - endTime
                    this._messageHtmlWriter.RenderBeginTag(HtmlTextWriterTag.Td);
                    this._messageHtmlWriter.Write(endTime.ToString());
                    this._messageHtmlWriter.RenderEndTag(); // </td>

                    // 10 - dataCode
                    // Disregard.

                    // 11 - dataBytes()
                    // Disregard.

                    this._messageHtmlWriter.RenderEndTag(); // </tr>
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                this._events.FireError(0, subComponentInfo, ex.Message, String.Empty, 0);
            }
        }

        #endregion
    }
}
