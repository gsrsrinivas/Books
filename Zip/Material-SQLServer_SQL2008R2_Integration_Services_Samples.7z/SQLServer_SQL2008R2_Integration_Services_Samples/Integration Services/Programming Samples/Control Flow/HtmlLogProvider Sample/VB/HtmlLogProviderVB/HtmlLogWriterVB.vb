Imports System.IO
Imports System.Web.UI
Imports System.Web

<System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1001:TypesThatOwnDisposableFieldsShouldBeDisposable")> _
Public Class HtmlLogWriterVB

#Region " Variables and Constants "

    ' Constants.
    Private Const MESSAGE_FORMAT As String = "html"

    ' Variables.
    <System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")> _
    Private _connections As Microsoft.SqlServer.Dts.Runtime.Connections
    Private _events As Microsoft.SqlServer.Dts.Runtime.IDTSInfoEvents
    Private _subComponent As String
    Private _messageHtmlWriter As HtmlTextWriter

    ' Status flags.
    <System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")> _
    Private _fireEventsAgain As Boolean

#End Region

#Region " Initialize "

    Friend Sub New()
        '
    End Sub

    Friend Sub InitializeLogWriter(ByVal connections As Microsoft.SqlServer.Dts.Runtime.Connections, ByVal events As Microsoft.SqlServer.Dts.Runtime.IDTSInfoEvents, ByVal subComponent As String, ByVal fireEventsAgain As Boolean)

        ' Cache object references for later use.
        _connections = connections
        _events = events

        _subComponent = subComponent
        _fireEventsAgain = fireEventsAgain

    End Sub

#End Region

#Region " OpenLog and CloseLog "

    Friend Sub OpenLogHtml(ByVal messageStreamWriter As StreamWriter)

        _messageHtmlWriter = New HtmlTextWriter(messageStreamWriter)

        With _messageHtmlWriter

            ' <html>
            .RenderBeginTag(HtmlTextWriterTag.Html)

            ' <head>
            .RenderBeginTag(HtmlTextWriterTag.Head)
            ' <title>
            .RenderBeginTag(HtmlTextWriterTag.Title)
            .Write("SSIS Package Log - " & DateTime.Now.ToString(System.Globalization.CultureInfo.InvariantCulture))
            .RenderEndTag() ' </title>
            .RenderEndTag() '</head>

            ' <body>
            .RenderBeginTag(HtmlTextWriterTag.Body)

            ' Create a title within the page.
            '  (There is no easy way to obtain and include the package name.)
            .RenderBeginTag(HtmlTextWriterTag.H1)
            .Write("SSIS Package Log - " & DateTime.Now.ToString(System.Globalization.CultureInfo.InvariantCulture))
            .RenderEndTag() ' </h1>

            ' <table>
            .AddAttribute(HtmlTextWriterAttribute.Width, "100%")
            .AddAttribute(HtmlTextWriterAttribute.Border, "1")
            .RenderBeginTag(HtmlTextWriterTag.Table)

            ' Write header row.
            .RenderBeginTag(HtmlTextWriterTag.Thead)
            .RenderBeginTag(HtmlTextWriterTag.Tr)

            ' 1 - logEntryName
            .RenderBeginTag(HtmlTextWriterTag.Th)
            .Write("Log Entry Name")
            .RenderEndTag() ' </th>

            ' 2 - computerName
            .RenderBeginTag(HtmlTextWriterTag.Th)
            .Write("Computer Name")
            .RenderEndTag() ' </th>

            ' 3 - operatorName
            .RenderBeginTag(HtmlTextWriterTag.Th)
            .Write("Operator Name")
            .RenderEndTag() ' </th>

            ' 4 - sourceName
            .RenderBeginTag(HtmlTextWriterTag.Th)
            .Write("Source Name")
            .RenderEndTag() ' </th>

            ' 5 - sourceID
            .RenderBeginTag(HtmlTextWriterTag.Th)
            .Write("Source ID")
            .RenderEndTag() ' </th>

            ' 6 - executionID
            .RenderBeginTag(HtmlTextWriterTag.Th)
            .Write("Execution ID")
            .RenderEndTag() ' </th>

            ' 7 - messageText
            .RenderBeginTag(HtmlTextWriterTag.Th)
            .Write("Message Text")
            .RenderEndTag() ' </th>

            ' 8 - startTime
            .RenderBeginTag(HtmlTextWriterTag.Th)
            .Write("Start Time")
            .RenderEndTag() ' </th>

            ' 9 - endTime
            .RenderBeginTag(HtmlTextWriterTag.Th)
            .Write("End Time")
            .RenderEndTag() ' </th>

            ' 10 - dataCode
            ' Disregard.

            ' 11 - dataBytes()
            ' Disregard.

            .RenderEndTag() ' </tr>
            .RenderEndTag() ' </thead>
        End With
    End Sub

    <System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")> _
    Friend Sub CloseLogHtml()

        Dim subComponentInfo As String = _
          _subComponent & "-CloseLogHtml (" & MESSAGE_FORMAT & ")"

        Try
            With _messageHtmlWriter
                .RenderEndTag() ' </table>
                .RenderEndTag() ' </body>
                .RenderEndTag() ' </html>
                .Flush()
                ' Do not close!
            End With
        Catch ex As Exception
            Console.WriteLine(ex.Message)
            _events.FireError(0, subComponentInfo, ex.Message, String.Empty, 0)
        End Try

    End Sub

#End Region

#Region " Write individual log entries "

    <System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA1801:ReviewUnusedParameters", MessageId:="dataCode")> _
    <System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA1801:ReviewUnusedParameters", MessageId:="dataBytes")> _
    <System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")> _
    Friend Sub LogHtml(ByVal logEntryName As String, ByVal computerName As String, _
      ByVal operatorName As String, ByVal sourceName As String, _
      ByVal sourceID As String, ByVal executionID As String, _
      ByVal messageText As String, ByVal startTime As Date, ByVal endTime As Date, _
      ByVal dataCode As Integer, ByVal dataBytes() As Byte)

        Dim subComponentInfo As String = _
          _subComponent & "-LogHtml (" & MESSAGE_FORMAT & ")"

        Try
            With _messageHtmlWriter

                .RenderBeginTag(HtmlTextWriterTag.Tr)

                ' 1 - logEntryName
                .RenderBeginTag(HtmlTextWriterTag.Td)
                .Write(logEntryName)
                .RenderEndTag() ' </td>

                ' 2 - computerName
                .RenderBeginTag(HtmlTextWriterTag.Td)
                .Write(computerName)
                .RenderEndTag() ' </td>

                ' 3 - operatorName
                .RenderBeginTag(HtmlTextWriterTag.Td)
                .Write(operatorName)
                .RenderEndTag() ' </td>

                ' 4 - sourceName
                .RenderBeginTag(HtmlTextWriterTag.Td)
                .Write(sourceName)
                .RenderEndTag() ' </td>

                ' 5 - sourceID
                .RenderBeginTag(HtmlTextWriterTag.Td)
                .Write(sourceID)
                .RenderEndTag() ' </td>

                ' 6 - executionID
                .RenderBeginTag(HtmlTextWriterTag.Td)
                .Write(executionID)
                .RenderEndTag() ' </td>

                ' 7 - messageText
                .RenderBeginTag(HtmlTextWriterTag.Td)
                ' Some event messages have no associated text.
                If String.IsNullOrEmpty(messageText) Then
                    .Write("&nbsp;")
                Else
                    .Write(HttpUtility.HtmlEncode(messageText))
                End If

                .RenderEndTag() ' </td>

                ' 8 - startTime
                .RenderBeginTag(HtmlTextWriterTag.Td)
                .Write(startTime.ToString(System.Globalization.CultureInfo.InvariantCulture))
                .RenderEndTag() ' </td>

                ' 9 - endTime
                .RenderBeginTag(HtmlTextWriterTag.Td)
                .Write(endTime.ToString(System.Globalization.CultureInfo.InvariantCulture))
                .RenderEndTag() ' </td>

                ' 10 - dataCode
                ' Disregard.

                ' 11 - dataBytes()
                ' Disregard.

                .RenderEndTag() ' </tr>

            End With
        Catch ex As Exception
            Console.WriteLine(ex.Message)
            _events.FireError(0, subComponentInfo, ex.Message, String.Empty, 0)
        End Try

    End Sub

#End Region

End Class
