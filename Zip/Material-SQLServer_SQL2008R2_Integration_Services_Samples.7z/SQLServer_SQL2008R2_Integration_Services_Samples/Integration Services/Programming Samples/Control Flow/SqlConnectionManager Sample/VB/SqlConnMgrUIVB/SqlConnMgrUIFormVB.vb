Imports Microsoft.SqlServer.Dts.Design
Imports Microsoft.SqlServer.Dts.Runtime
Imports Microsoft.SqlServer.Dts.Runtime.Wrapper
Imports Microsoft.SqlServer.Dts.Runtime.Design
Imports System.Windows.Forms
Imports System.Data.SqlClient

Public Class SqlConnMgrUIFormVB

    <System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")> Private Const CONNECTIONNAME_BASE As String = "SqlConnectionManagerVB"

  Private _connectionManager As ConnectionManager
    <System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")> Private _serviceProvider As IServiceProvider
  Private _connectionName As String
  Private _serverName As String
  Private _databaseName As String

  Public Sub Initialize(ByVal connectionManager As ConnectionManager, ByVal serviceProvider As IServiceProvider)

    _connectionManager = connectionManager
    _serviceProvider = serviceProvider
    ConfigureControlsFromConnectionManager()

  End Sub

#Region " Properties "

  Public ReadOnly Property ConnectionName() As String
    Get
      Return _connectionName
    End Get
  End Property

#End Region

#Region " Button events "

  Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click

    ConfigureConnectionManagerFromControls()
    Me.DialogResult = Windows.Forms.DialogResult.OK

  End Sub

  Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click

    Me.DialogResult = Windows.Forms.DialogResult.Cancel

  End Sub

#End Region

#Region " Helper functions "

  Private Sub ConfigureControlsFromConnectionManager()

    Dim tempServerName As String
    Dim tempDatabaseName As String

    With _connectionManager

      tempServerName = .Properties("ServerName").GetValue(_connectionManager).ToString
      If Not String.IsNullOrEmpty(tempServerName) Then
        _serverName = tempServerName
        txtServerName.Text = _serverName
      End If

      tempDatabaseName = .Properties("DatabaseName").GetValue(_connectionManager).ToString
      If Not String.IsNullOrEmpty(tempDatabaseName) Then
        _databaseName = tempDatabaseName
        txtDatabaseName.Text = _databaseName
      End If

    End With

  End Sub

  Private Sub ConfigureConnectionManagerFromControls()

    Dim tempServerName As String
    Dim tempDatabaseName As String

    tempServerName = txtServerName.Text
    tempDatabaseName = txtDatabaseName.Text

    _connectionName = CONNECTIONNAME_BASE & "." & tempServerName & "." & tempDatabaseName

    With _connectionManager
      .Properties("Name").SetValue(_connectionManager, _connectionName)
      .Properties("ServerName").SetValue(_connectionManager, tempServerName)
      .Properties("DatabaseName").SetValue(_connectionManager, tempDatabaseName)
    End With

  End Sub

#End Region

End Class
