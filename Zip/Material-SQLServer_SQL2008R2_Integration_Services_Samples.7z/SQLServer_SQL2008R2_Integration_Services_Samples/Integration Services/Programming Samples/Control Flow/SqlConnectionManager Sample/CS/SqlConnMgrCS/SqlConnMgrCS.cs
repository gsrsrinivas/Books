using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.SqlServer.Dts.Runtime;
using System.Data;
using System.Data.SqlClient;
using System.Xml;

namespace SqlConnMgrCS
{
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1724:TypeNamesShouldNotMatchNamespaces"), DtsConnection(ConnectionType = "SQLCS", DisplayName = "SqlConnectionManager (CS)",
    Description = "Connection manager for Sql Server",
   UITypeName = "SqlConnMgrUICS.SqlConnMgrUICS,SqlConnMgrUICS,Version=1.0.0.0,Culture=neutral,PublicKeyToken=<insert public key token here>")]
    public class SqlConnMgrCS :
    ConnectionManagerBase
    {
        private const string CONNECTIONSTRING_TEMPLATE = "Data Source=<servername>;Initial Catalog=<databasename>;Integrated Security=SSPI";

        private string _serverName = "(local)";
        private string _databaseName = "AdventureWorks";
        private string _connectionString = String.Empty;

        #region  Constructors

        public SqlConnMgrCS()
        {
            UpdateConnectionString();
        }

        public SqlConnMgrCS(string serverName, string databaseName)
        {
            this._serverName = serverName;
            this._databaseName = databaseName;

            UpdateConnectionString();
        }

        #endregion

        #region  Properties

        public string ServerName
        {
            get
            {
                return this._serverName;
            }

            set
            {
                this._serverName = value;
            }
        }

        public string DatabaseName
        {
            get
            {
                return this._databaseName;
            }
            
            set
            {
                this._databaseName = value;
            }
        }

        public override string ConnectionString
        {
            get
            {
                UpdateConnectionString();
                return this._connectionString;
            }
            
            set
            {
                this._connectionString = value;
            }
        }

        #endregion

        #region Methods

        public override object AcquireConnection(object txn)
        {
            SqlConnection sqlConnection = new SqlConnection();

            UpdateConnectionString();

            sqlConnection.ConnectionString = this._connectionString;
            sqlConnection.Open();

            return sqlConnection;
        }

        public override void ReleaseConnection(object connection)
        {
            SqlConnection sqlConnection;
            sqlConnection = (SqlConnection)connection;
            if (sqlConnection.State != ConnectionState.Closed)
            {
                sqlConnection.Close();
            }
        }

        public override Microsoft.SqlServer.Dts.Runtime.DTSExecResult Validate(Microsoft.SqlServer.Dts.Runtime.IDTSInfoEvents infoEvents)
        {
            if (String.IsNullOrEmpty(this._serverName))
            {
                infoEvents.FireError(0, "SqlConnectionManager", "No server name specified", String.Empty, 0);
                return DTSExecResult.Failure;
            }
            else
            {
                return DTSExecResult.Success;
            }
        }

        #endregion

        #region  Helper functions

        private void UpdateConnectionString()
        {
            string temporaryString = CONNECTIONSTRING_TEMPLATE;

            if (!String.IsNullOrEmpty(_serverName))
            {
                temporaryString = temporaryString.Replace("<servername>", this._serverName);
            }

            if (!String.IsNullOrEmpty(_databaseName))
            {
                temporaryString = temporaryString.Replace("<databasename>", this._databaseName);
            }

            this._connectionString = temporaryString;
        }

        #endregion
    }
}
