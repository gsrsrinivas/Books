'=====================================================================
'
'  File:    ForEachDirectoryUI.cs
'  Summary: This file contains the implementation of the user interface for the ForEachDirectory custom
'           enumerator. It is loaded in the ForEachLoop container editor and displayed when the Collection node
'           in the editor is clicked. The ForEachEnumeratorUI class derives from UserControl.
'
'  Date:    November 18, 2004
'
'---------------------------------------------------------------------
'
'  This file is part of the Microsoft SQL Server Code Samples.
'  Copyright (C) Microsoft Corporation.  All rights reserved.
'
'  This source code is intended only as a supplement to Microsoft
'  Development Tools andor on-line documentation.  See these other
'  materials for detailed information regarding Microsoft code samples.
'
'  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY ANDOR FITNESS FOR A
'  PARTICULAR PURPOSE.
'
'===================================================================== 
Imports System
Imports System.Windows.Forms
Imports System.Windows.Forms.ComponentModel
Imports System.Drawing
Imports Microsoft.SqlServer.Dts.Runtime
Imports Microsoft.SqlServer.Dts.Runtime.Design

Public Class ForEachDirectoryUI
    Inherits ForEachEnumeratorUI
#Region "Members"
    Private cons As Connections
    Private vars As Variables
    Private fed As ForEachDirectory
    Private chkIncludeRoot As System.Windows.Forms.CheckBox
    Private chkSiblingsBeforeSubFolders As System.Windows.Forms.CheckBox
    Private WithEvents cboRootDirSource As System.Windows.Forms.ComboBox
    Private cboRootDirectory As System.Windows.Forms.ComboBox
    Private WithEvents chkEnumerateSubFolders As System.Windows.Forms.CheckBox
    Private lblRootDirectorySource As System.Windows.Forms.Label
    Private lblRootDirectory As System.Windows.Forms.Label

    Private components As System.ComponentModel.Container = Nothing

#End Region

#Region "Ctor  InitializeComponent  Dispose"

    Public Sub New()
        InitializeComponent()
    End Sub 'New

    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If

        MyBase.Dispose(disposing)
    End Sub

#Region "InitializeComponent"

    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ForEachDirectoryUI))
        Me.cboRootDirSource = New System.Windows.Forms.ComboBox
        Me.lblRootDirectorySource = New System.Windows.Forms.Label
        Me.cboRootDirectory = New System.Windows.Forms.ComboBox
        Me.lblRootDirectory = New System.Windows.Forms.Label
        Me.chkIncludeRoot = New System.Windows.Forms.CheckBox
        Me.chkSiblingsBeforeSubFolders = New System.Windows.Forms.CheckBox
        Me.chkEnumerateSubFolders = New System.Windows.Forms.CheckBox
        Me.SuspendLayout()
        '
        'cboRootDirSource
        '
        Me.cboRootDirSource.DisplayMember = "0"
        Me.cboRootDirSource.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboRootDirSource.FormattingEnabled = True
        Me.cboRootDirSource.Items.AddRange(New Object() {resources.GetString("cboRootDirSource.Items"), resources.GetString("cboRootDirSource.Items1"), resources.GetString("cboRootDirSource.Items2")})
        resources.ApplyResources(Me.cboRootDirSource, "cboRootDirSource")
        Me.cboRootDirSource.Name = "cboRootDirSource"
        '
        'lblRootDirectorySource
        '
        resources.ApplyResources(Me.lblRootDirectorySource, "lblRootDirectorySource")
        Me.lblRootDirectorySource.Name = "lblRootDirectorySource"
        '
        'cboRootDirectory
        '
        Me.cboRootDirectory.FormattingEnabled = True
        resources.ApplyResources(Me.cboRootDirectory, "cboRootDirectory")
        Me.cboRootDirectory.Name = "cboRootDirectory"
        '
        'lblRootDirectory
        '
        resources.ApplyResources(Me.lblRootDirectory, "lblRootDirectory")
        Me.lblRootDirectory.Name = "lblRootDirectory"
        '
        'chkIncludeRoot
        '
        resources.ApplyResources(Me.chkIncludeRoot, "chkIncludeRoot")
        Me.chkIncludeRoot.Name = "chkIncludeRoot"
        '
        'chkSiblingsBeforeSubFolders
        '
        resources.ApplyResources(Me.chkSiblingsBeforeSubFolders, "chkSiblingsBeforeSubFolders")
        Me.chkSiblingsBeforeSubFolders.Name = "chkSiblingsBeforeSubFolders"
        '
        'chkEnumerateSubFolders
        '
        resources.ApplyResources(Me.chkEnumerateSubFolders, "chkEnumerateSubFolders")
        Me.chkEnumerateSubFolders.Name = "chkEnumerateSubFolders"
        '
        'ForEachDirectoryUI
        '
        Me.Controls.Add(Me.chkEnumerateSubFolders)
        Me.Controls.Add(Me.chkSiblingsBeforeSubFolders)
        Me.Controls.Add(Me.chkIncludeRoot)
        Me.Controls.Add(Me.lblRootDirectory)
        Me.Controls.Add(Me.cboRootDirectory)
        Me.Controls.Add(Me.lblRootDirectorySource)
        Me.Controls.Add(Me.cboRootDirSource)
        Me.Name = "ForEachDirectoryUI"
        resources.ApplyResources(Me, "$this")
        Me.ResumeLayout(False)

    End Sub 'InitializeComponent 
#End Region

#End Region

#Region "Initialize"

    ' <summary>
    ' This method is called when the ForEachLoop user interface is displayed. During this method the windows form controls 
    ' in this class representing the properties of the ForEachDirectory enumerator are initialized 
    ' from the property values of the enumerator. 
    ' enumerator.
    ' <summary>
    ' <param name="FEEHost">The Host object containing the ForEachDirectory enumerator in the InnerObject property.
    ' <param name="connections">The collection of ConnectionManager objects in the package.<param>
    ' <param name="variables">The collection of Variable objects in the package.<param>
    Public Overrides Sub Initialize(ByVal FEEHost As ForEachEnumeratorHost, ByVal serviceProvider As IServiceProvider, ByVal connections As Connections, ByVal variables As Variables)
        If (FEEHost Is Nothing) Then
            Throw New ArgumentNullException("FEEHost")
        End If

        Me.cons = connections
        Me.vars = variables

        Me.fed = CType(FEEHost.InnerObject, ForEachDirectory)

        If Not (Me.fed Is Nothing) Then
            Me.chkIncludeRoot.Checked = Me.fed.IncludeRootDirectory
            Me.chkEnumerateSubFolders.Checked = Me.fed.EnumerateSubFolders
            Me.chkSiblingsBeforeSubFolders.Checked = Me.fed.SiblingFoldersBeforeSubFolders
            Me.chkSiblingsBeforeSubFolders.Enabled = Me.chkEnumerateSubFolders.Checked

            If Me.fed.RootDirectorySourceValue = ForEachDirectory.RootDirectorySource.DirectInput Then
                Me.cboRootDirSource.SelectedIndex = Me.cboRootDirSource.Items.IndexOf("DirectInput")
                Me.cboRootDirectory.Text = Me.fed.RootDirectory
            ElseIf Me.fed.RootDirectorySourceValue = ForEachDirectory.RootDirectorySource.Variable Then
                Me.cboRootDirSource.SelectedIndex = Me.cboRootDirSource.Items.IndexOf("Variable")

                For Each v As Variable In Me.vars
                    cboRootDirectory.Items.Add(v.Name)
                Next

                Me.cboRootDirectory.SelectedIndex = Me.cboRootDirectory.Items.IndexOf(Me.fed.RootDirectory)
            Else
                Me.cboRootDirSource.SelectedIndex = Me.cboRootDirSource.Items.IndexOf("ConnectionManager")

                For Each cm As ConnectionManager In Me.cons
                    cboRootDirectory.Items.Add(cm.Name)
                Next

                Me.cboRootDirectory.SelectedIndex = Me.cboRootDirectory.Items.IndexOf(Me.fed.RootDirectory)
            End If
        End If
    End Sub
#End Region

#Region "SaveSettings"

    ' <summary>
    ' This method is called if the user clicks OK on the ForEachLoop container's editor. The values of the
    ' ForEachDirectory enumerator are updated based on the values contained in the controls in the UserControl.
    ' <summary>
    Public Overrides Sub SaveSettings()
        Me.fed.IncludeRootDirectory = Me.chkIncludeRoot.Checked
        Me.fed.SiblingFoldersBeforeSubFolders = Me.chkSiblingsBeforeSubFolders.Checked
        Me.fed.EnumerateSubFolders = Me.chkEnumerateSubFolders.Checked

        If Me.cboRootDirSource.SelectedItem.ToString() = "DirectInput" Then
            Me.fed.RootDirectorySourceValue = ForEachDirectory.RootDirectorySource.DirectInput
            Me.fed.RootDirectory = Me.cboRootDirectory.Text
        ElseIf Me.cboRootDirSource.SelectedItem.ToString() = "ConnectionManager" Then
            Me.fed.RootDirectorySourceValue = ForEachDirectory.RootDirectorySource.ConnectionManager
            Me.fed.RootDirectory = Me.cboRootDirectory.Text
        Else
            Me.fed.RootDirectorySourceValue = ForEachDirectory.RootDirectorySource.Variable
            Me.fed.RootDirectory = Me.cboRootDirectory.Text
        End If
    End Sub 'SaveSettings 
#End Region

#Region "Control Events"

    Private Sub cboRootDirSource_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboRootDirSource.SelectedIndexChanged
        Me.cboRootDirectory.Items.Clear()

        Dim rootDir As New ForEachDirectory.RootDirectorySource()

        Me.cboRootDirectory.DropDownStyle = ComboBoxStyle.DropDownList
        If Me.cboRootDirSource.SelectedItem.ToString() = "DirectInput" Then
            Me.cboRootDirectory.DropDownStyle = ComboBoxStyle.DropDown
            rootDir = ForEachDirectory.RootDirectorySource.DirectInput
        ElseIf Me.cboRootDirSource.SelectedItem.ToString() = "ConnectionManager" Then
            rootDir = ForEachDirectory.RootDirectorySource.ConnectionManager
        Else
            rootDir = ForEachDirectory.RootDirectorySource.Variable
        End If

        SelectRootDirSource(rootDir)
    End Sub


    Private Sub SelectRootDirSource(ByVal rootDirSource As ForEachDirectory.RootDirectorySource)
        ' Start fresh
        cboRootDirectory.Items.Clear()

        If rootDirSource = ForEachDirectory.RootDirectorySource.DirectInput Then
            ' Do nothing
        ElseIf rootDirSource = ForEachDirectory.RootDirectorySource.Variable Then
            For Each v As Variable In Me.vars
                cboRootDirectory.Items.Add(v.Name)
            Next
        Else
            For Each cm As ConnectionManager In Me.cons
                cboRootDirectory.Items.Add(cm.Name)
            Next
        End If
    End Sub

    Private Sub chkEnumerateSubFolders_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkEnumerateSubFolders.CheckedChanged
        Me.chkSiblingsBeforeSubFolders.Enabled = Me.chkEnumerateSubFolders.Checked
    End Sub
#End Region
End Class
