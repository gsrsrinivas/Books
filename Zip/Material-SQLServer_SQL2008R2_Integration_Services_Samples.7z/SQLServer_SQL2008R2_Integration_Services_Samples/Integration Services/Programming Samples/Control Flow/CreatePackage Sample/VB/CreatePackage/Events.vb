'=====================================================================  	
'
'  File:		Events.vb
'
'  Summary:	Implementation of package events
'
'  Date:		06/09/2005
'
'---------------------------------------------------------------------
'  This file is part of the Microsoft SQL Server Code Samples.
'  Copyright (C) Microsoft Corporation.  All rights reserved.
'
'	This source code is intended only as a supplement to Microsoft
'	Development Tools and/or on-line documentation.  See these other
'	materials for detailed information regarding Microsoft code samples.
'
'	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
'  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
'  THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
'	PARTICULAR PURPOSE.
'=====================================================================  	

Namespace Microsoft.Samples.SqlServer.SSIS
    Public Class PackageEvents
        Implements IDTSEvents

        Sub OnBreakpointHit(ByVal breakpointSite As IDTSBreakpointSite, ByVal breakpointTarget As BreakpointTarget) Implements IDTSEvents.OnBreakpointHit
            ' TODO:  Add PackageEvents.OnBreakpointHit implementation
        End Sub

        Function OnQueryCancel() As Boolean Implements IDTSEvents.OnQueryCancel
            ' TODO:  Add PackageEvents.OnQueryCancel implementation
            Return False
        End Function

        Sub OnTaskFailed(ByVal taskHost As TaskHost) Implements IDTSEvents.OnTaskFailed
            If (taskHost = Nothing) Then
                Throw New ArgumentNullException("taskHost")
            End If

            Console.WriteLine("OnTaskFailed " & taskHost.Name & vbLf)
        End Sub

        Sub OnWarning(ByVal source As DtsObject, ByVal warningCode As Integer, ByVal subComponent As String, ByVal description As String, ByVal helpFile As String, ByVal helpContext As Integer, ByVal idofInterfaceWithError As String) Implements IDTSEvents.OnWarning
            If (source = Nothing) Then
                Throw New ArgumentNullException("source")
            End If

            Dim sourceName As String = (CType(source, IDTSName)).Name

            Console.WriteLine("OnWarning " & vbLf & "WarningCode " & warningCode _
                & vbLf & "Source  " & sourceName & vbLf & "SubComponent " & subComponent _
                & vbLf & "Description " & description & "IDOfInterfaceWithError " _
                & idofInterfaceWithError & vbLf)
        End Sub

        Sub OnCustomEvent(ByVal taskHost As TaskHost, ByVal eventName As String, ByVal eventText As String, ByRef arguments() As Object, ByVal subComponent As String, ByRef fireAgain As Boolean) Implements IDTSEvents.OnCustomEvent
            ' TODO:  Add PackageEvents.OnCustomEvent implementation
        End Sub

        Sub OnProgress(ByVal taskHost As TaskHost, ByVal progressDescription As String, ByVal percentComplete As Integer, ByVal progressCountLow As Integer, ByVal progressCountHigh As Integer, ByVal subComponent As String, ByRef fireAgain As Boolean) Implements IDTSEvents.OnProgress
            If (taskHost = Nothing) Then
                Throw New ArgumentNullException("taskHost")
            End If

            Console.WriteLine("OnProgress " & vbLf & "TaskHost " & taskHost.Name _
                & vbLf & "ProgressDescription " & progressDescription _
                & vbLf & "PercentComplete " & percentComplete.ToString( _
                CultureInfo.InvariantCulture) & vbLf)
        End Sub

        Sub OnInformation(ByVal [source] As DtsObject, ByVal informationCode As Integer, ByVal subComponent As String, ByVal description As String, ByVal helpFile As String, ByVal helpContext As Integer, ByVal idofInterfaceWithError As String, ByRef fireAgain As Boolean) Implements IDTSEvents.OnInformation
            Console.WriteLine("OnInformation" & vbLf & "SubComponent: " _
                & subComponent & vbLf & "Description: " & description)
        End Sub

        <System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1725:ParameterNamesShouldMatchBaseDeclaration")> Sub OnVariableValueChanged(ByVal dtsContainer As DtsContainer, ByVal variable As Variable, ByRef fireAgain As Boolean) Implements IDTSEvents.OnVariableValueChanged
            ' TODO:  Add PackageEvents.OnVariableValueChanged implementation
        End Sub

        Function OnError(ByVal source As DtsObject, ByVal errorCode As Integer, ByVal subComponent As String, ByVal description As String, ByVal helpFile As String, ByVal helpContext As Integer, ByVal idofInterfaceWithError As String) As Boolean Implements IDTSEvents.OnError
            If (source = Nothing) Then
                Throw New ArgumentNullException("source")
            End If

            Dim sourceName As String = CType(source, IDTSName).Name

            Console.WriteLine("OnError " & vbLf & "ErrorCode " & errorCode _
                & vbLf & "Source " & sourceName & vbLf & "SubComponent " & subComponent _
                & vbLf & "Description " & description & vbLf & "IDOfInterfaceWithError " _
                & idofInterfaceWithError & vbLf)

            Return False
        End Function

        Sub OnPreExecute(ByVal exec As Executable, ByRef fireAgain As Boolean) Implements IDTSEvents.OnPreExecute
            Dim th As TaskHost = TryCast(exec, TaskHost)
            Dim p As Package = TryCast(exec, Package)

            If th Is Nothing Then
                Console.WriteLine("OnPreExecute\n" & p.Name & vbLf)
            ElseIf p Is Nothing Then
                Console.WriteLine("OnPreExecute\n" & th.Name & vbLf)
            End If
        End Sub

        Sub OnPostExecute(ByVal exec As Executable, ByRef fireAgain As Boolean) Implements IDTSEvents.OnPostExecute
            Dim th As TaskHost = TryCast(exec, TaskHost)
            Dim p As Package = TryCast(exec, Package)

            If th Is Nothing Then
                Console.WriteLine("OnPostExecute\n" & p.Name & vbLf)
            ElseIf p Is Nothing Then
                Console.WriteLine("OnPostExecute\n" & th.Name & vbLf)
            End If
        End Sub

        Sub OnPostValidate(ByVal exec As Executable, ByRef fireAgain As Boolean) Implements IDTSEvents.OnPostValidate
            Dim th As TaskHost = TryCast(exec, TaskHost)
            Dim p As Package = TryCast(exec, Package)

            If th Is Nothing Then
                Console.WriteLine("OnPostValidate\n" & p.Name & vbLf)
            ElseIf p Is Nothing Then
                Console.WriteLine("OnPostValidate\n" & th.Name & vbLf)
            End If
        End Sub

        Sub OnPreValidate(ByVal exec As Executable, ByRef fireAgain As Boolean) Implements IDTSEvents.OnPreValidate
            Dim th As TaskHost = TryCast(exec, TaskHost)
            Dim p As Package = TryCast(exec, Package)

            If th Is Nothing Then
                Console.WriteLine("OnPreValidate\n" & p.Name & vbLf)
            ElseIf p Is Nothing Then
                Console.WriteLine("OnPreValidate\n" & th.Name & vbLf)
            End If
        End Sub

        Sub OnExecutionStatusChanged(ByVal exec As Executable, ByVal newStatus As DTSExecStatus, ByRef fireAgain As Boolean) Implements IDTSEvents.OnExecutionStatusChanged
            ' TODO:  Add PackageEvents.OnExecutionStatusChanged implementation
        End Sub
    End Class


    Public Class ComponentEvents
        Implements IDTSComponentEvents
        <System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1030:UseEventsWhereAppropriate")> Public Sub FireBreakpointHit(ByVal breakpointTarget As BreakpointTarget) Implements IDTSComponentEvents.FireBreakpointHit
        End Sub

        <System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1030:UseEventsWhereAppropriate")> Public Function FireQueryCancel() As Boolean Implements IDTSComponentEvents.FireQueryCancel
            Return False
        End Function

        <System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1030:UseEventsWhereAppropriate")> Public Sub FireWarning(ByVal warningCode As Integer, ByVal subComponent As String, ByVal description As String, ByVal helpFile As String, ByVal helpContext As Integer) Implements IDTSComponentEvents.FireWarning
            Console.WriteLine("OnWarning" & vbLf & "WarningCode " _
                & warningCode.ToString(CultureInfo.InvariantCulture) & vbLf _
                & "SubComponent " & subComponent & vbLf & "Description " _
                & description & vbLf)
        End Sub

        <System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1030:UseEventsWhereAppropriate")> Public Sub FireCustomEvent(ByVal eventName As String, ByVal eventText As String, ByRef arguments() As Object, ByVal subComponent As String, ByRef fireAgain As Boolean) Implements IDTSComponentEvents.FireCustomEvent
        End Sub

        <System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1030:UseEventsWhereAppropriate")> Public Sub FireProgress(ByVal progressDescription As String, ByVal percentComplete As Integer, ByVal progressCountLow As Integer, ByVal progressCountHigh As Integer, ByVal subComponent As String, ByRef fireAgain As Boolean) Implements IDTSComponentEvents.FireProgress
            Console.WriteLine("OnProgress " & progressDescription _
                & vbLf & "PercentComplete " & percentComplete)
        End Sub

        <System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1030:UseEventsWhereAppropriate")> Public Function FireError(ByVal errorCode As Integer, ByVal subComponent As String, ByVal description As String, ByVal helpFile As String, ByVal helpContext As Integer) As Boolean Implements IDTSComponentEvents.FireError
            Console.WriteLine("OnError" & vbLf & "ErrorCode " _
                & errorCode.ToString(CultureInfo.InvariantCulture) & vbLf _
                & "SubComponent " & subComponent & vbLf & "Description " _
                & description)
            Return False
        End Function

        <System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1030:UseEventsWhereAppropriate")> Public Sub FireInformation(ByVal informationCode As Integer, ByVal subComponent As String, ByVal description As String, ByVal helpFile As String, ByVal helpContext As Integer, ByRef fireAgain As Boolean) Implements IDTSComponentEvents.FireInformation
            Console.WriteLine("FireInformation" & vbLf & "SubComponent: " _
                & subComponent & vbLf & "Description: " & description & vbLf _
                & "InformationCode: " & informationCode)
        End Sub
    End Class
End Namespace
