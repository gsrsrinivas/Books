/*=====================================================================
  This file is part of a Microsoft SQL Server Shared Source Application.
  Copyright (C) Microsoft Corporation.  All rights reserved.
 
THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.
======================================================= */
-- Generate changes
insert into CDCSample.Customer
select CustomerID, PersonID, StoreID, TerritoryID, rowguid, getdate()
from Sales.Customer
where CustomerID > 8000 and CustomerID <= 12000
go
-- Delay 10 seconds
waitfor delay '00:00:10'
go
-- Generate changes
insert into CDCSample.Customer
select CustomerID, PersonID, StoreID, TerritoryID, rowguid, getdate()
from Sales.Customer
where CustomerID > 12000 and CustomerID <= 13000
go
-- Delay 10 seconds
waitfor delay '00:00:10'
go
-- Generate changes
insert into CDCSample.Customer
select CustomerID, PersonID, StoreID, TerritoryID, rowguid, getdate()
from Sales.Customer
where CustomerID > 13000 and CustomerID <= 14000
go
-- Delay 10 seconds
waitfor delay '00:00:10'
go
-- Generate changes
insert into CDCSample.Customer
select CustomerID, PersonID, StoreID, TerritoryID, rowguid, getdate()
from Sales.Customer
where CustomerID > 14000 and CustomerID <= 15000
go
-- Delay 10 seconds
waitfor delay '00:00:10'
go
-- Generate changes
insert into CDCSample.Customer
select CustomerID, PersonID, StoreID, TerritoryID, rowguid, getdate()
from Sales.Customer
where CustomerID > 15000 and CustomerID <= 16000
go
-- Delay 10 seconds
waitfor delay '00:00:10'
go
-- Generate changes
insert into CDCSample.Customer
select CustomerID, PersonID, StoreID, TerritoryID, rowguid, getdate()
from Sales.Customer
where CustomerID > 16000 and CustomerID <= 17000
go
-- Delay 10 seconds
waitfor delay '00:00:10'
go
-- Generate changes
insert into CDCSample.Customer
select CustomerID, PersonID, StoreID, TerritoryID, rowguid, getdate()
from Sales.Customer
where CustomerID > 17000 and CustomerID <= 18000
go
-- Delay 10 seconds
waitfor delay '00:00:10'
go
-- Generate changes
insert into CDCSample.Customer
select CustomerID, PersonID, StoreID, TerritoryID, rowguid, getdate()
from Sales.Customer
where CustomerID > 18000 and CustomerID <= 19000
go
-- Delay 10 seconds
waitfor delay '00:00:10'
go
-- Generate changes
insert into CDCSample.Customer
select CustomerID, PersonID, StoreID, TerritoryID, rowguid, getdate()
from Sales.Customer
where CustomerID > 19000 and CustomerID <= 20000
go
-- Delay 10 seconds
waitfor delay '00:00:10'
go
-- Generate changes
insert into CDCSample.Customer
select CustomerID, PersonID, StoreID, TerritoryID, rowguid, getdate()
from Sales.Customer
where CustomerID > 20000 and CustomerID <= 21000
go
-- Delay 10 seconds
waitfor delay '00:00:10'
go
-- Generate changes
insert into CDCSample.Customer
select CustomerID, PersonID, StoreID, TerritoryID, rowguid, getdate()
from Sales.Customer
where CustomerID > 21000 and CustomerID <= 22000
go
-- Delay 10 seconds
waitfor delay '00:00:10'
go
-- Generate changes
insert into CDCSample.Customer
select CustomerID, PersonID, StoreID, TerritoryID, rowguid, getdate()
from Sales.Customer
where CustomerID > 22000 and CustomerID <= 23000
go
-- Delay 10 seconds
waitfor delay '00:00:10'
go
-- Generate changes
insert into CDCSample.Customer
select CustomerID, PersonID, StoreID, TerritoryID, rowguid, getdate()
from Sales.Customer
where CustomerID > 23000 and CustomerID <= 25000
go
-- Delay 10 seconds
waitfor delay '00:00:10'
go
-- Generate changes
insert into CDCSample.Customer
select CustomerID, PersonID, StoreID, TerritoryID, rowguid, getdate()
from Sales.Customer
where CustomerID > 25000 and CustomerID <= 27000
go
-- Delay 10 seconds
waitfor delay '00:00:10'
go
-- Generate changes
insert into CDCSample.Customer
select CustomerID, PersonID, StoreID, TerritoryID, rowguid, getdate()
from Sales.Customer
where CustomerID > 27000 and CustomerID <= 29000
go
-- Delay 10 seconds
waitfor delay '00:00:10'
go
-- Generate changes
insert into CDCSample.Customer
select CustomerID, PersonID, StoreID, TerritoryID, rowguid, getdate()
from Sales.Customer
where CustomerID > 29000 and CustomerID <= 32000
go
-- Delay 10 seconds
waitfor delay '00:00:10'
go

